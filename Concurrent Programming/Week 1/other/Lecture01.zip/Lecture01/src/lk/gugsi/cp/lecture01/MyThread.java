package lk.gugsi.cp.lecture01;
public class MyThread {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		// How many threads are there and what is the name of thread?
		// Every program by default will have one thread and in case of Java
		// Application that thread name is main thread 
		// Single Threaded Apartment 
		// main method executes on the main thread 

	}

}
