- Formal methods are used to detect errors in software
- It is required for certain critical software.
- B methods are abstract and mathematical
- Different from UML 

TODOs 
- Install atelierB and prob