![[Pasted image 20241009141937.png]]
- This is not a Venn diagram
- Initial States are also valid states.
- Invalid states means there is an error in the system
- 29th February could be an invalid state.
	- It could start as a valid (initial state) date and end up as an invalid one.

### Static features of the machine
- Sets
- initialization
- Constants
- Variables
- etc.

### Dynamic features of the machine
- Operations

## Abstract Machine Parameters
- We can pass sets and constants to the machine.
![[Pasted image 20241009150857.png]]
- sets are always capital
![[Pasted image 20241009150937.png]]
- constants should be defined in the constraints section. Sets doesnt need to be defined.



### TODO
![[Pasted image 20241009152220.png]]
[[TODO]] Clarify why we have to mention house number is a NAT1 even when we define it as a member of the houseset.


