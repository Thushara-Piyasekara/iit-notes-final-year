`;` is used at the end of operation when there are subsequent operations after that.
![[Pasted image 20241002111512.png]]