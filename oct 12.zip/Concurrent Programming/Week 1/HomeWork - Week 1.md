![[Pasted image 20241010231335.png]]
